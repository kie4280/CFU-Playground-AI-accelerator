extern const float label8_data[];
