extern const float label0_data[];
