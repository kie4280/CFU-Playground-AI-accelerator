extern const float label6_data[];
